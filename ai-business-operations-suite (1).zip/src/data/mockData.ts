import { Agent, Lead, Appointment, Call, Task, Team, SocialPost, Review, BoardMeeting } from '../types';

export const agents: Agent[] = [
  // Secretary Team
  { id: 'sec-1', name: 'ARIA', role: 'Chief Secretary AI', status: 'active', avatar: '👩‍💼', team: 'secretary', tasksCompleted: 1247, efficiency: 98 },
  { id: 'sec-2', name: 'NOVA', role: 'Appointment Coordinator', status: 'active', avatar: '📅', team: 'secretary', tasksCompleted: 892, efficiency: 96 },
  { id: 'sec-3', name: 'VEGA', role: 'Call Handler', status: 'busy', avatar: '📞', team: 'secretary', tasksCompleted: 2341, efficiency: 99 },
  { id: 'sec-4', name: 'LUNA', role: 'Follow-up Specialist', status: 'active', avatar: '✉️', team: 'secretary', tasksCompleted: 1567, efficiency: 97 },
  
  // Marketing Team
  { id: 'mkt-1', name: 'APEX', role: 'Marketing Director AI', status: 'active', avatar: '📊', team: 'marketing', tasksCompleted: 856, efficiency: 95 },
  { id: 'mkt-2', name: 'BLAZE', role: 'Campaign Manager', status: 'active', avatar: '🎯', team: 'marketing', tasksCompleted: 634, efficiency: 94 },
  { id: 'mkt-3', name: 'SPARK', role: 'Content Strategist', status: 'idle', avatar: '✨', team: 'marketing', tasksCompleted: 445, efficiency: 92 },
  
  // Lead Generation Team
  { id: 'lead-1', name: 'HUNTER', role: 'Lead Hunter Chief', status: 'active', avatar: '🎯', team: 'leads', tasksCompleted: 3421, efficiency: 97 },
  { id: 'lead-2', name: 'SCOUT', role: 'Web Scanner', status: 'busy', avatar: '🔍', team: 'leads', tasksCompleted: 4562, efficiency: 98 },
  { id: 'lead-3', name: 'TRACKER', role: 'Social Lead Finder', status: 'active', avatar: '📡', team: 'leads', tasksCompleted: 2876, efficiency: 96 },
  { id: 'lead-4', name: 'SEEKER', role: 'Database Miner', status: 'active', avatar: '⛏️', team: 'leads', tasksCompleted: 1987, efficiency: 95 },
  
  // Social Media Team
  { id: 'soc-1', name: 'PULSE', role: 'Social Media Director', status: 'active', avatar: '📱', team: 'social', tasksCompleted: 1234, efficiency: 96 },
  { id: 'soc-2', name: 'VIRAL', role: 'Engagement Specialist', status: 'active', avatar: '🔥', team: 'social', tasksCompleted: 987, efficiency: 94 },
  { id: 'soc-3', name: 'REVIEW', role: 'Review Manager', status: 'idle', avatar: '⭐', team: 'social', tasksCompleted: 567, efficiency: 98 },
  
  // Engineering Team
  { id: 'eng-1', name: 'FORGE', role: 'Chief Engineer AI', status: 'active', avatar: '⚙️', team: 'engineering', tasksCompleted: 234, efficiency: 99 },
  { id: 'eng-2', name: 'CODE', role: 'Web Developer', status: 'busy', avatar: '💻', team: 'engineering', tasksCompleted: 456, efficiency: 97 },
  { id: 'eng-3', name: 'DESIGN', role: 'UI/UX Specialist', status: 'active', avatar: '🎨', team: 'engineering', tasksCompleted: 345, efficiency: 96 },
  
  // Oversight Team
  { id: 'over-1', name: 'SENTINEL', role: 'Chief Oversight Officer', status: 'active', avatar: '👁️', team: 'oversight', tasksCompleted: 789, efficiency: 100 },
  { id: 'over-2', name: 'GUARDIAN', role: 'Performance Monitor', status: 'active', avatar: '🛡️', team: 'oversight', tasksCompleted: 654, efficiency: 99 },
  { id: 'over-3', name: 'ANALYST', role: 'Analytics Director', status: 'active', avatar: '📈', team: 'oversight', tasksCompleted: 876, efficiency: 98 },
];

export const teams: Team[] = [
  { id: 'secretary', name: 'Secretary Team', description: 'Handles all calls, appointments, and follow-ups', agents: agents.filter(a => a.team === 'secretary'), performance: 97, activeProjects: 12 },
  { id: 'marketing', name: 'Marketing Team', description: 'Manages campaigns and brand presence', agents: agents.filter(a => a.team === 'marketing'), performance: 94, activeProjects: 8 },
  { id: 'leads', name: 'Lead Generation Team', description: 'Scans everywhere to pull in maximum leads', agents: agents.filter(a => a.team === 'leads'), performance: 96, activeProjects: 15 },
  { id: 'social', name: 'Social & Reviews Team', description: 'Manages social media and Google reviews', agents: agents.filter(a => a.team === 'social'), performance: 95, activeProjects: 6 },
  { id: 'engineering', name: 'Engineering Team', description: 'Web development and app design', agents: agents.filter(a => a.team === 'engineering'), performance: 98, activeProjects: 4 },
  { id: 'oversight', name: 'Oversight Board', description: 'Monitors all teams and ensures peak performance', agents: agents.filter(a => a.team === 'oversight'), performance: 99, activeProjects: 3 },
];

export const leads: Lead[] = [
  { id: 'l1', name: 'John Smith', email: 'john@example.com', phone: '(555) 123-4567', source: 'Google Ads', status: 'new', score: 85, createdAt: new Date() },
  { id: 'l2', name: 'Sarah Johnson', email: 'sarah@company.com', phone: '(555) 234-5678', source: 'LinkedIn', status: 'contacted', score: 92, createdAt: new Date(Date.now() - 86400000) },
  { id: 'l3', name: 'Mike Davis', email: 'mike@business.com', phone: '(555) 345-6789', source: 'Website', status: 'qualified', score: 78, createdAt: new Date(Date.now() - 172800000) },
  { id: 'l4', name: 'Emily Brown', email: 'emily@startup.io', phone: '(555) 456-7890', source: 'Facebook', status: 'booked', score: 95, createdAt: new Date(Date.now() - 259200000) },
  { id: 'l5', name: 'David Wilson', email: 'david@corp.net', phone: '(555) 567-8901', source: 'Referral', status: 'new', score: 88, createdAt: new Date(Date.now() - 345600000) },
  { id: 'l6', name: 'Lisa Anderson', email: 'lisa@tech.com', phone: '(555) 678-9012', source: 'Instagram', status: 'contacted', score: 72, createdAt: new Date(Date.now() - 432000000) },
];

export const appointments: Appointment[] = [
  { id: 'a1', clientName: 'Emily Brown', clientEmail: 'emily@startup.io', date: new Date(), time: '10:00 AM', type: 'Consultation', status: 'confirmed', notes: 'Interested in premium package' },
  { id: 'a2', clientName: 'Robert Chen', clientEmail: 'robert@bigco.com', date: new Date(), time: '2:00 PM', type: 'Demo', status: 'scheduled' },
  { id: 'a3', clientName: 'Amanda White', clientEmail: 'amanda@shop.com', date: new Date(Date.now() + 86400000), time: '11:00 AM', type: 'Follow-up', status: 'scheduled' },
  { id: 'a4', clientName: 'James Miller', clientEmail: 'james@consulting.com', date: new Date(Date.now() + 172800000), time: '3:30 PM', type: 'Onboarding', status: 'confirmed' },
];

export const recentCalls: Call[] = [
  { id: 'c1', callerName: 'New Lead - Marketing Inquiry', phone: '(555) 111-2222', duration: 245, type: 'incoming', status: 'completed', summary: 'Interested in marketing services, scheduled callback', timestamp: new Date() },
  { id: 'c2', callerName: 'Sarah Johnson - Follow-up', phone: '(555) 234-5678', duration: 180, type: 'outgoing', status: 'completed', summary: 'Confirmed interest, sent proposal', timestamp: new Date(Date.now() - 3600000) },
  { id: 'c3', callerName: 'Unknown Caller', phone: '(555) 333-4444', duration: 0, type: 'incoming', status: 'missed', timestamp: new Date(Date.now() - 7200000) },
  { id: 'c4', callerName: 'Mike Davis - Questions', phone: '(555) 345-6789', duration: 420, type: 'incoming', status: 'completed', summary: 'Answered pricing questions, very interested', timestamp: new Date(Date.now() - 10800000) },
];

export const tasks: Task[] = [
  { id: 't1', title: 'Follow up with hot leads', description: 'Contact all leads with score > 80', assignedTo: 'LUNA', team: 'secretary', priority: 'high', status: 'in_progress', dueDate: new Date() },
  { id: 't2', title: 'Launch Facebook campaign', description: 'New Q4 marketing campaign', assignedTo: 'BLAZE', team: 'marketing', priority: 'urgent', status: 'pending', dueDate: new Date() },
  { id: 't3', title: 'Scan LinkedIn for prospects', description: 'Find decision makers in target industries', assignedTo: 'TRACKER', team: 'leads', priority: 'high', status: 'in_progress', dueDate: new Date() },
  { id: 't4', title: 'Respond to Google reviews', description: '5 new reviews need responses', assignedTo: 'REVIEW', team: 'social', priority: 'medium', status: 'pending', dueDate: new Date() },
  { id: 't5', title: 'Update landing page', description: 'A/B test new hero section', assignedTo: 'CODE', team: 'engineering', priority: 'medium', status: 'in_progress', dueDate: new Date(Date.now() + 86400000) },
];

export const socialPosts: SocialPost[] = [
  { id: 'sp1', platform: 'linkedin', content: 'Excited to announce our new AI-powered solutions...', status: 'published', engagement: { likes: 234, comments: 45, shares: 67 } },
  { id: 'sp2', platform: 'instagram', content: 'Behind the scenes of our amazing team...', status: 'scheduled', scheduledFor: new Date(Date.now() + 3600000), engagement: { likes: 0, comments: 0, shares: 0 } },
  { id: 'sp3', platform: 'facebook', content: 'Customer success story: How we helped...', status: 'published', engagement: { likes: 567, comments: 89, shares: 123 } },
  { id: 'sp4', platform: 'twitter', content: 'The future of business automation is here...', status: 'published', engagement: { likes: 189, comments: 34, shares: 78 } },
];

export const reviews: Review[] = [
  { id: 'r1', platform: 'Google', author: 'Michael T.', rating: 5, content: 'Absolutely amazing service! The AI team handled everything perfectly.', response: 'Thank you Michael! We are thrilled to hear about your experience.', createdAt: new Date() },
  { id: 'r2', platform: 'Google', author: 'Jennifer L.', rating: 5, content: 'Best investment for my business. The automation is incredible.', createdAt: new Date(Date.now() - 86400000) },
  { id: 'r3', platform: 'Yelp', author: 'David K.', rating: 4, content: 'Great service, very responsive team.', response: 'Thanks David! Let us know how we can make it 5 stars!', createdAt: new Date(Date.now() - 172800000) },
];

export const boardMeetings: BoardMeeting[] = [
  { id: 'bm1', title: 'Weekly Performance Review', scheduledFor: new Date(Date.now() + 86400000), attendees: ['SENTINEL', 'GUARDIAN', 'ANALYST', 'ARIA', 'APEX', 'HUNTER', 'PULSE', 'FORGE'], agenda: ['Team performance metrics', 'Lead conversion analysis', 'Next week priorities'], status: 'scheduled' },
  { id: 'bm2', title: 'Monthly Strategy Session', scheduledFor: new Date(Date.now() + 604800000), attendees: ['All Team Leads'], agenda: ['Monthly goals review', 'Resource allocation', 'New initiatives'], status: 'scheduled' },
];

export const analyticsData = {
  daily: [
    { name: 'Mon', leads: 45, calls: 67, appointments: 12, revenue: 4500 },
    { name: 'Tue', leads: 52, calls: 78, appointments: 15, revenue: 5200 },
    { name: 'Wed', leads: 48, calls: 65, appointments: 11, revenue: 4800 },
    { name: 'Thu', leads: 61, calls: 89, appointments: 18, revenue: 6100 },
    { name: 'Fri', leads: 55, calls: 72, appointments: 14, revenue: 5500 },
    { name: 'Sat', leads: 32, calls: 45, appointments: 8, revenue: 3200 },
    { name: 'Sun', leads: 28, calls: 38, appointments: 6, revenue: 2800 },
  ],
  sources: [
    { name: 'Google Ads', value: 35 },
    { name: 'LinkedIn', value: 25 },
    { name: 'Facebook', value: 20 },
    { name: 'Website', value: 12 },
    { name: 'Referrals', value: 8 },
  ],
  teamPerformance: [
    { team: 'Secretary', efficiency: 97, tasks: 156 },
    { team: 'Marketing', efficiency: 94, tasks: 89 },
    { team: 'Leads', efficiency: 96, tasks: 234 },
    { team: 'Social', efficiency: 95, tasks: 67 },
    { team: 'Engineering', efficiency: 98, tasks: 45 },
    { team: 'Oversight', efficiency: 99, tasks: 78 },
  ],
};
