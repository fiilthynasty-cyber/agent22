import { 
  Phone, 
  Calendar, 
  Target, 
  TrendingUp, 
  Users, 
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
  Zap,
  Clock,
  CheckCircle2
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { analyticsData, leads, appointments, agents, tasks } from '../data/mockData';
import { cn } from '../utils/cn';

const COLORS = ['#06b6d4', '#8b5cf6', '#f59e0b', '#10b981', '#ec4899'];

export function Dashboard() {
  const stats = [
    { label: 'Calls Today', value: '127', change: '+12%', positive: true, icon: Phone, color: 'cyan' },
    { label: 'Appointments', value: '24', change: '+8%', positive: true, icon: Calendar, color: 'purple' },
    { label: 'New Leads', value: '89', change: '+23%', positive: true, icon: Target, color: 'emerald' },
    { label: 'Revenue Today', value: '$12,450', change: '+15%', positive: true, icon: DollarSign, color: 'amber' },
  ];

  const activeAgents = agents.filter(a => a.status === 'active' || a.status === 'busy');

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-700/50 p-8">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-pink-500/10" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-cyan-500/20 to-purple-500/20 rounded-full blur-3xl" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-5 h-5 text-cyan-400" />
            <span className="text-sm font-medium text-cyan-400">Live Dashboard</span>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Good Morning, Admin</h1>
          <p className="text-slate-400 max-w-xl">
            Your AI team is operating at peak performance. {activeAgents.length} agents are currently active, 
            handling calls, booking appointments, and hunting leads across all channels.
          </p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6 hover:border-slate-600/50 transition-all">
              <div className="flex items-start justify-between mb-4">
                <div className={cn(
                  'w-12 h-12 rounded-xl flex items-center justify-center',
                  stat.color === 'cyan' && 'bg-cyan-500/20',
                  stat.color === 'purple' && 'bg-purple-500/20',
                  stat.color === 'emerald' && 'bg-emerald-500/20',
                  stat.color === 'amber' && 'bg-amber-500/20',
                )}>
                  <Icon className={cn(
                    'w-6 h-6',
                    stat.color === 'cyan' && 'text-cyan-400',
                    stat.color === 'purple' && 'text-purple-400',
                    stat.color === 'emerald' && 'text-emerald-400',
                    stat.color === 'amber' && 'text-amber-400',
                  )} />
                </div>
                <div className={cn(
                  'flex items-center gap-1 text-sm font-medium',
                  stat.positive ? 'text-emerald-400' : 'text-red-400'
                )}>
                  {stat.positive ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                  {stat.change}
                </div>
              </div>
              <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
              <p className="text-sm text-slate-400">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-3 gap-6">
        {/* Performance Chart */}
        <div className="col-span-2 bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-white">Performance Overview</h3>
              <p className="text-sm text-slate-400">Daily leads, calls, and appointments</p>
            </div>
            <div className="flex gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-cyan-500" />
                <span className="text-xs text-slate-400">Leads</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-purple-500" />
                <span className="text-xs text-slate-400">Calls</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-emerald-500" />
                <span className="text-xs text-slate-400">Appointments</span>
              </div>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={analyticsData.daily}>
              <defs>
                <linearGradient id="colorLeads" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorCalls" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorAppointments" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="name" stroke="#64748b" fontSize={12} />
              <YAxis stroke="#64748b" fontSize={12} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1e293b', 
                  border: '1px solid #334155', 
                  borderRadius: '12px',
                  color: '#fff'
                }} 
              />
              <Area type="monotone" dataKey="leads" stroke="#06b6d4" fillOpacity={1} fill="url(#colorLeads)" strokeWidth={2} />
              <Area type="monotone" dataKey="calls" stroke="#8b5cf6" fillOpacity={1} fill="url(#colorCalls)" strokeWidth={2} />
              <Area type="monotone" dataKey="appointments" stroke="#10b981" fillOpacity={1} fill="url(#colorAppointments)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Lead Sources */}
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-2">Lead Sources</h3>
          <p className="text-sm text-slate-400 mb-4">Where your leads come from</p>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={analyticsData.sources}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {analyticsData.sources.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1e293b', 
                  border: '1px solid #334155', 
                  borderRadius: '12px',
                  color: '#fff'
                }} 
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-4">
            {analyticsData.sources.map((source, index) => (
              <div key={source.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index] }} />
                  <span className="text-sm text-slate-300">{source.name}</span>
                </div>
                <span className="text-sm font-medium text-white">{source.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-3 gap-6">
        {/* Recent Leads */}
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Hot Leads</h3>
            <span className="text-xs px-2 py-1 rounded-full bg-cyan-500/20 text-cyan-400 font-medium">Live</span>
          </div>
          <div className="space-y-3">
            {leads.slice(0, 4).map((lead) => (
              <div key={lead.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-all">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-purple-500 flex items-center justify-center text-white font-bold text-sm">
                  {lead.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">{lead.name}</p>
                  <p className="text-xs text-slate-400">{lead.source}</p>
                </div>
                <div className={cn(
                  'text-xs font-bold px-2 py-1 rounded-full',
                  lead.score >= 90 ? 'bg-emerald-500/20 text-emerald-400' :
                  lead.score >= 75 ? 'bg-amber-500/20 text-amber-400' :
                  'bg-slate-500/20 text-slate-400'
                )}>
                  {lead.score}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Today's Appointments */}
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Today's Appointments</h3>
            <span className="text-xs px-2 py-1 rounded-full bg-purple-500/20 text-purple-400 font-medium">{appointments.filter(a => a.date.toDateString() === new Date().toDateString()).length} Today</span>
          </div>
          <div className="space-y-3">
            {appointments.slice(0, 4).map((apt) => (
              <div key={apt.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-all">
                <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-purple-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">{apt.clientName}</p>
                  <p className="text-xs text-slate-400">{apt.type}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-white">{apt.time}</p>
                  <p className={cn(
                    'text-xs',
                    apt.status === 'confirmed' ? 'text-emerald-400' : 'text-amber-400'
                  )}>{apt.status}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Active Tasks */}
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Active Tasks</h3>
            <span className="text-xs px-2 py-1 rounded-full bg-emerald-500/20 text-emerald-400 font-medium">{tasks.filter(t => t.status === 'in_progress').length} In Progress</span>
          </div>
          <div className="space-y-3">
            {tasks.slice(0, 4).map((task) => (
              <div key={task.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-all">
                <div className={cn(
                  'w-10 h-10 rounded-xl flex items-center justify-center',
                  task.status === 'completed' ? 'bg-emerald-500/20' : 
                  task.priority === 'urgent' ? 'bg-red-500/20' :
                  task.priority === 'high' ? 'bg-amber-500/20' : 'bg-slate-500/20'
                )}>
                  {task.status === 'completed' ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <Zap className={cn(
                      'w-5 h-5',
                      task.priority === 'urgent' ? 'text-red-400' :
                      task.priority === 'high' ? 'text-amber-400' : 'text-slate-400'
                    )} />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">{task.title}</p>
                  <p className="text-xs text-slate-400">{task.assignedTo}</p>
                </div>
                <div className={cn(
                  'text-xs font-medium px-2 py-1 rounded-full',
                  task.priority === 'urgent' ? 'bg-red-500/20 text-red-400' :
                  task.priority === 'high' ? 'bg-amber-500/20 text-amber-400' :
                  'bg-slate-500/20 text-slate-400'
                )}>
                  {task.priority}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Active Agents Strip */}
      <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 to-purple-500/20 flex items-center justify-center">
              <Users className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">Active AI Agents</h3>
              <p className="text-sm text-slate-400">{activeAgents.length} agents currently working</p>
            </div>
          </div>
          <button className="px-4 py-2 rounded-xl bg-slate-800 text-sm font-medium text-slate-300 hover:bg-slate-700 transition-all">
            View All Teams
          </button>
        </div>
        <div className="flex gap-3 overflow-x-auto pb-2">
          {activeAgents.slice(0, 10).map((agent) => (
            <div key={agent.id} className="flex-shrink-0 w-36 p-4 rounded-xl bg-slate-800/50 border border-slate-700/50 hover:border-cyan-500/30 transition-all">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-2xl">{agent.avatar}</span>
                <div className={cn(
                  'w-2 h-2 rounded-full',
                  agent.status === 'active' ? 'bg-emerald-400 shadow-lg shadow-emerald-400/50' :
                  agent.status === 'busy' ? 'bg-amber-400 shadow-lg shadow-amber-400/50' :
                  'bg-slate-400'
                )} />
              </div>
              <p className="text-sm font-semibold text-white mb-1">{agent.name}</p>
              <p className="text-xs text-slate-400 truncate">{agent.role}</p>
              <div className="mt-2 flex items-center gap-1">
                <TrendingUp className="w-3 h-3 text-emerald-400" />
                <span className="text-xs text-emerald-400">{agent.efficiency}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
