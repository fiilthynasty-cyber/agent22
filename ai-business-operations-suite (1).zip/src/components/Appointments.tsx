import { Calendar, Clock, User, Plus, Check, X, Mail, Phone, ChevronLeft, ChevronRight } from 'lucide-react';
import { appointments } from '../data/mockData';
import { cn } from '../utils/cn';
import { useState } from 'react';

export function Appointments() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showNewModal, setShowNewModal] = useState(false);

  const currentMonth = selectedDate.getMonth();
  const currentYear = selectedDate.getFullYear();
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
  
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const emptyDays = Array.from({ length: firstDayOfMonth }, (_, i) => i);

  const goToPrevMonth = () => {
    setSelectedDate(new Date(currentYear, currentMonth - 1, 1));
  };

  const goToNextMonth = () => {
    setSelectedDate(new Date(currentYear, currentMonth + 1, 1));
  };

  const upcomingAppointments = appointments.filter(a => 
    a.date >= new Date()
  ).slice(0, 5);

  const timeSlots = [
    '9:00 AM', '9:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
    '12:00 PM', '12:30 PM', '1:00 PM', '1:30 PM', '2:00 PM', '2:30 PM',
    '3:00 PM', '3:30 PM', '4:00 PM', '4:30 PM', '5:00 PM'
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Appointment Management</h1>
          <p className="text-slate-400">AI-powered scheduling by NOVA & ARIA</p>
        </div>
        <button 
          onClick={() => setShowNewModal(true)}
          className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 text-white font-medium hover:from-purple-600 hover:to-pink-600 transition-all"
        >
          <Plus className="w-5 h-5" />
          New Appointment
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center mb-4">
            <Calendar className="w-6 h-6 text-purple-400" />
          </div>
          <p className="text-3xl font-bold text-white mb-1">24</p>
          <p className="text-sm text-slate-400">Today's Appointments</p>
        </div>
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center mb-4">
            <Check className="w-6 h-6 text-emerald-400" />
          </div>
          <p className="text-3xl font-bold text-white mb-1">18</p>
          <p className="text-sm text-slate-400">Confirmed</p>
        </div>
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 flex items-center justify-center mb-4">
            <Clock className="w-6 h-6 text-amber-400" />
          </div>
          <p className="text-3xl font-bold text-white mb-1">6</p>
          <p className="text-sm text-slate-400">Pending</p>
        </div>
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/20 flex items-center justify-center mb-4">
            <User className="w-6 h-6 text-cyan-400" />
          </div>
          <p className="text-3xl font-bold text-white mb-1">156</p>
          <p className="text-sm text-slate-400">This Week</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Calendar */}
        <div className="col-span-2 bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-white">
              {selectedDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
            </h3>
            <div className="flex gap-2">
              <button 
                onClick={goToPrevMonth}
                className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition-all"
              >
                <ChevronLeft className="w-5 h-5 text-slate-400" />
              </button>
              <button 
                onClick={goToNextMonth}
                className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition-all"
              >
                <ChevronRight className="w-5 h-5 text-slate-400" />
              </button>
            </div>
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-2 mb-4">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="text-center text-sm font-medium text-slate-500 py-2">
                {day}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-2">
            {emptyDays.map(i => (
              <div key={`empty-${i}`} className="aspect-square" />
            ))}
            {days.map(day => {
              const isToday = day === new Date().getDate() && 
                selectedDate.getMonth() === new Date().getMonth() && 
                selectedDate.getFullYear() === new Date().getFullYear();
              const hasAppointments = appointments.some(a => 
                a.date.getDate() === day && 
                a.date.getMonth() === selectedDate.getMonth()
              );
              return (
                <button
                  key={day}
                  className={cn(
                    'aspect-square rounded-xl flex flex-col items-center justify-center transition-all relative',
                    isToday 
                      ? 'bg-gradient-to-br from-purple-500 to-pink-500 text-white' 
                      : 'bg-slate-800/50 text-slate-300 hover:bg-slate-700'
                  )}
                >
                  <span className="text-sm font-medium">{day}</span>
                  {hasAppointments && !isToday && (
                    <div className="absolute bottom-2 w-1.5 h-1.5 rounded-full bg-cyan-400" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Time Slots */}
          <div className="mt-6 pt-6 border-t border-slate-700/50">
            <h4 className="text-sm font-semibold text-white mb-4">Available Time Slots</h4>
            <div className="flex flex-wrap gap-2">
              {timeSlots.map(slot => {
                const isBooked = appointments.some(a => a.time === slot);
                return (
                  <button
                    key={slot}
                    disabled={isBooked}
                    className={cn(
                      'px-4 py-2 rounded-lg text-sm font-medium transition-all',
                      isBooked 
                        ? 'bg-slate-800/50 text-slate-600 cursor-not-allowed line-through' 
                        : 'bg-slate-800 text-slate-300 hover:bg-purple-500/20 hover:text-purple-400 hover:border-purple-500/30 border border-transparent'
                    )}
                  >
                    {slot}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Upcoming Appointments */}
        <div className="space-y-6">
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Upcoming Appointments</h3>
            <div className="space-y-3">
              {upcomingAppointments.map((apt) => (
                <div key={apt.id} className="p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-all">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold text-sm">
                      {apt.clientName.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-white">{apt.clientName}</p>
                      <p className="text-xs text-slate-400">{apt.type}</p>
                    </div>
                    <div className={cn(
                      'px-2 py-1 rounded-full text-xs font-medium',
                      apt.status === 'confirmed' ? 'bg-emerald-500/20 text-emerald-400' :
                      apt.status === 'scheduled' ? 'bg-amber-500/20 text-amber-400' :
                      'bg-slate-500/20 text-slate-400'
                    )}>
                      {apt.status}
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-slate-400">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {apt.date.toLocaleDateString()}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {apt.time}
                    </div>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <button className="flex-1 flex items-center justify-center gap-1 px-3 py-2 rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 transition-all text-sm">
                      <Mail className="w-4 h-4" />
                      Email
                    </button>
                    <button className="flex-1 flex items-center justify-center gap-1 px-3 py-2 rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 transition-all text-sm">
                      <Phone className="w-4 h-4" />
                      Call
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* AI Scheduling Stats */}
          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <span className="text-2xl">📅</span>
              <div>
                <p className="font-semibold text-white">AI Scheduling</p>
                <p className="text-xs text-slate-400">NOVA Agent</p>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-400">Auto-booked today</span>
                <span className="text-sm font-medium text-white">18</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-400">Confirmations sent</span>
                <span className="text-sm font-medium text-white">24</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-400">Reminders today</span>
                <span className="text-sm font-medium text-white">12</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-400">Reschedules handled</span>
                <span className="text-sm font-medium text-white">3</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* New Appointment Modal */}
      {showNewModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 w-full max-w-lg">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">New Appointment</h3>
              <button 
                onClick={() => setShowNewModal(false)}
                className="p-2 rounded-lg hover:bg-slate-800 transition-all"
              >
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2">Client Name</label>
                <input 
                  type="text" 
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                  placeholder="Enter client name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2">Email</label>
                <input 
                  type="email" 
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                  placeholder="client@example.com"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-2">Date</label>
                  <input 
                    type="date" 
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-2">Time</label>
                  <select className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500">
                    {timeSlots.map(slot => (
                      <option key={slot} value={slot}>{slot}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2">Type</label>
                <select className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500">
                  <option>Consultation</option>
                  <option>Demo</option>
                  <option>Follow-up</option>
                  <option>Onboarding</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2">Notes</label>
                <textarea 
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 h-24 resize-none"
                  placeholder="Add any notes..."
                />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button 
                onClick={() => setShowNewModal(false)}
                className="flex-1 px-6 py-3 rounded-xl bg-slate-800 text-slate-300 font-medium hover:bg-slate-700 transition-all"
              >
                Cancel
              </button>
              <button 
                onClick={() => setShowNewModal(false)}
                className="flex-1 px-6 py-3 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 text-white font-medium hover:from-purple-600 hover:to-pink-600 transition-all"
              >
                Book Appointment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
