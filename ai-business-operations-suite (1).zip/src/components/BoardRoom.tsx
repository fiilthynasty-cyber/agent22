import { Users, Calendar, Video, Play, FileText, Clock, CheckCircle2, AlertCircle, MessageSquare } from 'lucide-react';
import { boardMeetings, agents } from '../data/mockData';
import { cn } from '../utils/cn';
import { useState } from 'react';

export function BoardRoom() {
  const [showMeetingModal, setShowMeetingModal] = useState(false);
  const oversightAgents = agents.filter(a => a.team === 'oversight');
  const teamLeads = agents.filter(a => a.role.includes('Chief') || a.role.includes('Director'));

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Board Room</h1>
          <p className="text-slate-400">AI Board Meetings & Executive Conferences</p>
        </div>
        <button 
          onClick={() => setShowMeetingModal(true)}
          className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-medium hover:from-indigo-600 hover:to-purple-600 transition-all"
        >
          <Video className="w-5 h-5" />
          Start Board Meeting
        </button>
      </div>

      {/* Live Meeting Banner */}
      <div className="bg-gradient-to-r from-indigo-900/50 via-purple-900/50 to-indigo-900/50 border border-indigo-500/30 rounded-2xl p-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-purple-500/10 to-indigo-500/5" />
        <div className="absolute top-4 right-4 flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse shadow-lg shadow-emerald-400/50" />
          <span className="text-xs font-medium text-emerald-400">READY</span>
        </div>
        <div className="relative flex items-center gap-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center text-3xl">
            👁️
          </div>
          <div>
            <h3 className="text-xl font-bold text-white mb-1">SENTINEL - Chief Oversight Officer</h3>
            <p className="text-slate-400">Ready to convene board meeting. All team leads on standby.</p>
            <div className="flex items-center gap-4 mt-3">
              <div className="flex -space-x-2">
                {teamLeads.slice(0, 6).map(agent => (
                  <div 
                    key={agent.id}
                    className="w-8 h-8 rounded-full bg-slate-700 border-2 border-slate-900 flex items-center justify-center text-sm"
                    title={agent.name}
                  >
                    {agent.avatar}
                  </div>
                ))}
              </div>
              <span className="text-sm text-slate-400">{teamLeads.length} executives available</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Scheduled Meetings */}
        <div className="col-span-2 space-y-6">
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Scheduled Board Meetings</h3>
            <div className="space-y-4">
              {boardMeetings.map(meeting => (
                <div key={meeting.id} className="p-5 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-all">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h4 className="font-semibold text-white mb-1">{meeting.title}</h4>
                      <div className="flex items-center gap-4 text-sm text-slate-400">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {meeting.scheduledFor.toLocaleDateString()}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {meeting.scheduledFor.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>
                    </div>
                    <span className={cn(
                      'px-3 py-1 rounded-full text-xs font-medium',
                      meeting.status === 'scheduled' ? 'bg-amber-500/20 text-amber-400' :
                      meeting.status === 'in_progress' ? 'bg-emerald-500/20 text-emerald-400' :
                      'bg-slate-500/20 text-slate-400'
                    )}>
                      {meeting.status.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="mb-4">
                    <p className="text-xs text-slate-500 uppercase font-semibold mb-2">Agenda</p>
                    <div className="space-y-2">
                      {meeting.agenda.map((item, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm text-slate-300">
                          <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                          {item}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-slate-500" />
                      <span className="text-sm text-slate-400">{meeting.attendees.length} attendees</span>
                    </div>
                    <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-indigo-500/20 text-indigo-400 text-sm font-medium hover:bg-indigo-500/30 transition-all">
                      <Play className="w-4 h-4" />
                      Join Meeting
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Meeting Minutes */}
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Recent Meeting Minutes</h3>
            <div className="space-y-3">
              {[
                { title: 'Weekly Performance Review', date: 'Oct 28, 2024', decisions: 5 },
                { title: 'Q3 Strategy Session', date: 'Oct 21, 2024', decisions: 8 },
                { title: 'Marketing Campaign Review', date: 'Oct 14, 2024', decisions: 4 },
              ].map((minutes, idx) => (
                <div key={idx} className="flex items-center gap-4 p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-all cursor-pointer">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/20 flex items-center justify-center">
                    <FileText className="w-5 h-5 text-indigo-400" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-white">{minutes.title}</p>
                    <p className="text-xs text-slate-400">{minutes.date}</p>
                  </div>
                  <span className="text-xs text-indigo-400">{minutes.decisions} decisions</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Oversight Team & Quick Actions */}
        <div className="space-y-6">
          {/* Oversight Team */}
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Oversight Board</h3>
            <div className="space-y-3">
              {oversightAgents.map(agent => (
                <div key={agent.id} className="p-4 rounded-xl bg-slate-800/50">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-2xl">{agent.avatar}</span>
                    <div className="flex-1">
                      <p className="font-semibold text-white">{agent.name}</p>
                      <p className="text-xs text-slate-400">{agent.role}</p>
                    </div>
                    <div className={cn(
                      'w-2 h-2 rounded-full',
                      agent.status === 'active' ? 'bg-emerald-400 shadow-lg shadow-emerald-400/50' : 'bg-slate-400'
                    )} />
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-400">Oversight tasks</span>
                    <span className="text-white font-medium">{agent.tasksCompleted}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Active Alerts */}
          <div className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/20 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-amber-400" />
              Active Alerts
            </h3>
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-slate-800/50">
                <p className="text-sm text-amber-400 font-medium">Marketing Team</p>
                <p className="text-xs text-slate-400">Campaign CTR below target</p>
              </div>
              <div className="p-3 rounded-lg bg-slate-800/50">
                <p className="text-sm text-cyan-400 font-medium">Lead Team</p>
                <p className="text-xs text-slate-400">High volume - scaling resources</p>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
            <div className="space-y-2">
              <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 transition-all text-sm">
                <MessageSquare className="w-4 h-4 text-indigo-400" />
                Send Team Memo
              </button>
              <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 transition-all text-sm">
                <FileText className="w-4 h-4 text-cyan-400" />
                Generate Report
              </button>
              <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 transition-all text-sm">
                <Video className="w-4 h-4 text-purple-400" />
                Emergency Meeting
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* New Meeting Modal */}
      {showMeetingModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 w-full max-w-lg">
            <h3 className="text-xl font-bold text-white mb-6">Start Board Meeting</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2">Meeting Title</label>
                <input 
                  type="text"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500"
                  placeholder="Enter meeting title"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2">Select Attendees</label>
                <div className="flex flex-wrap gap-2">
                  {teamLeads.map(agent => (
                    <button 
                      key={agent.id}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-indigo-500/20 hover:text-indigo-400 transition-all text-sm"
                    >
                      <span>{agent.avatar}</span>
                      {agent.name}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2">Agenda Items</label>
                <textarea 
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500 h-24 resize-none"
                  placeholder="Enter agenda items (one per line)"
                />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button 
                onClick={() => setShowMeetingModal(false)}
                className="flex-1 px-6 py-3 rounded-xl bg-slate-800 text-slate-300 font-medium hover:bg-slate-700 transition-all"
              >
                Cancel
              </button>
              <button 
                onClick={() => setShowMeetingModal(false)}
                className="flex-1 px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-medium hover:from-indigo-600 hover:to-purple-600 transition-all flex items-center justify-center gap-2"
              >
                <Video className="w-4 h-4" />
                Start Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
