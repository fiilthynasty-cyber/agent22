import { Phone, PhoneIncoming, PhoneOutgoing, PhoneMissed, Play, Pause, MoreVertical, Mic, MicOff, Volume2 } from 'lucide-react';
import { recentCalls, agents } from '../data/mockData';
import { cn } from '../utils/cn';
import { useState } from 'react';

export function CallCenter() {
  const [activeCall, setActiveCall] = useState(false);
  const [muted, setMuted] = useState(false);

  const callAgents = agents.filter(a => a.team === 'secretary');
  
  const stats = [
    { label: 'Total Calls Today', value: '127', icon: Phone, color: 'cyan' },
    { label: 'Incoming', value: '89', icon: PhoneIncoming, color: 'emerald' },
    { label: 'Outgoing', value: '32', icon: PhoneOutgoing, color: 'purple' },
    { label: 'Missed', value: '6', icon: PhoneMissed, color: 'red' },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">AI Call Center</h1>
          <p className="text-slate-400">Automated call handling powered by VEGA, NOVA & ARIA</p>
        </div>
        <button 
          onClick={() => setActiveCall(!activeCall)}
          className={cn(
            "flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all",
            activeCall 
              ? "bg-red-500 text-white hover:bg-red-600" 
              : "bg-gradient-to-r from-cyan-500 to-blue-500 text-white hover:from-cyan-600 hover:to-blue-600"
          )}
        >
          {activeCall ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
          {activeCall ? 'End Demo Call' : 'Start Demo Call'}
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
              <div className={cn(
                'w-12 h-12 rounded-xl flex items-center justify-center mb-4',
                stat.color === 'cyan' && 'bg-cyan-500/20',
                stat.color === 'emerald' && 'bg-emerald-500/20',
                stat.color === 'purple' && 'bg-purple-500/20',
                stat.color === 'red' && 'bg-red-500/20',
              )}>
                <Icon className={cn(
                  'w-6 h-6',
                  stat.color === 'cyan' && 'text-cyan-400',
                  stat.color === 'emerald' && 'text-emerald-400',
                  stat.color === 'purple' && 'text-purple-400',
                  stat.color === 'red' && 'text-red-400',
                )} />
              </div>
              <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
              <p className="text-sm text-slate-400">{stat.label}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Active Call Panel */}
        <div className="col-span-2 space-y-6">
          {/* Live Call Simulation */}
          {activeCall && (
            <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 border border-cyan-500/30 rounded-2xl p-6 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 to-purple-500/5" />
              <div className="absolute top-4 right-4 flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
                <span className="text-xs font-medium text-red-400">LIVE</span>
              </div>
              <div className="relative">
                <div className="flex items-center gap-6 mb-6">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-cyan-500 to-purple-500 flex items-center justify-center text-3xl">
                    👩‍💼
                  </div>
                  <div>
                    <p className="text-sm text-cyan-400 font-medium mb-1">AI Agent: VEGA handling call</p>
                    <h3 className="text-xl font-bold text-white">Incoming Call - New Lead</h3>
                    <p className="text-slate-400">(555) 123-4567 • Duration: 02:34</p>
                  </div>
                </div>
                
                {/* Transcript */}
                <div className="bg-slate-800/50 rounded-xl p-4 mb-6 max-h-48 overflow-y-auto">
                  <h4 className="text-xs font-semibold text-slate-400 uppercase mb-3">Live Transcript</h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex gap-3">
                      <span className="text-cyan-400 font-medium">VEGA:</span>
                      <span className="text-slate-300">"Good morning! Thank you for calling NexusAI. How can I assist you today?"</span>
                    </div>
                    <div className="flex gap-3">
                      <span className="text-amber-400 font-medium">Caller:</span>
                      <span className="text-slate-300">"Hi, I'm interested in learning more about your AI services."</span>
                    </div>
                    <div className="flex gap-3">
                      <span className="text-cyan-400 font-medium">VEGA:</span>
                      <span className="text-slate-300">"I'd be happy to help! Can I get your name and the best way to reach you?"</span>
                    </div>
                    <div className="flex gap-3 animate-pulse">
                      <span className="text-slate-500">●●●</span>
                      <span className="text-slate-500">Listening...</span>
                    </div>
                  </div>
                </div>

                {/* Controls */}
                <div className="flex items-center justify-center gap-4">
                  <button 
                    onClick={() => setMuted(!muted)}
                    className={cn(
                      "p-4 rounded-full transition-all",
                      muted ? "bg-red-500/20 text-red-400" : "bg-slate-700 text-white hover:bg-slate-600"
                    )}
                  >
                    {muted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                  </button>
                  <button className="p-4 rounded-full bg-slate-700 text-white hover:bg-slate-600 transition-all">
                    <Volume2 className="w-6 h-6" />
                  </button>
                  <button 
                    onClick={() => setActiveCall(false)}
                    className="px-8 py-4 rounded-full bg-red-500 text-white hover:bg-red-600 transition-all font-medium"
                  >
                    End Call
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Recent Calls */}
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Recent Calls</h3>
            <div className="space-y-3">
              {recentCalls.map((call) => (
                <div key={call.id} className="flex items-center gap-4 p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-all">
                  <div className={cn(
                    'w-12 h-12 rounded-xl flex items-center justify-center',
                    call.status === 'completed' ? 'bg-emerald-500/20' :
                    call.status === 'missed' ? 'bg-red-500/20' : 'bg-amber-500/20'
                  )}>
                    {call.type === 'incoming' ? (
                      <PhoneIncoming className={cn(
                        'w-5 h-5',
                        call.status === 'completed' ? 'text-emerald-400' :
                        call.status === 'missed' ? 'text-red-400' : 'text-amber-400'
                      )} />
                    ) : (
                      <PhoneOutgoing className="w-5 h-5 text-purple-400" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-white">{call.callerName}</p>
                    <p className="text-sm text-slate-400">{call.phone}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-slate-300">
                      {call.duration > 0 ? `${Math.floor(call.duration / 60)}:${(call.duration % 60).toString().padStart(2, '0')}` : 'Missed'}
                    </p>
                    <p className="text-xs text-slate-500">
                      {call.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                  <button className="p-2 rounded-lg hover:bg-slate-700 transition-all">
                    <MoreVertical className="w-4 h-4 text-slate-400" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Call Agents */}
        <div className="space-y-6">
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Call Handling Agents</h3>
            <div className="space-y-3">
              {callAgents.map((agent) => (
                <div key={agent.id} className="p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-all">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-2xl">{agent.avatar}</span>
                    <div className="flex-1">
                      <p className="font-semibold text-white">{agent.name}</p>
                      <p className="text-xs text-slate-400">{agent.role}</p>
                    </div>
                    <div className={cn(
                      'w-3 h-3 rounded-full',
                      agent.status === 'active' ? 'bg-emerald-400 shadow-lg shadow-emerald-400/50' :
                      agent.status === 'busy' ? 'bg-amber-400 shadow-lg shadow-amber-400/50 animate-pulse' :
                      'bg-slate-400'
                    )} />
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-400">Calls handled:</span>
                    <span className="text-white font-medium">{agent.tasksCompleted}</span>
                  </div>
                  <div className="mt-2 h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full"
                      style={{ width: `${agent.efficiency}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-500 mt-1">{agent.efficiency}% efficiency</p>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Call Metrics</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Avg. Wait Time</span>
                <span className="text-white font-medium">0.3s</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Avg. Call Duration</span>
                <span className="text-white font-medium">4:32</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Resolution Rate</span>
                <span className="text-emerald-400 font-medium">94%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Callback Scheduled</span>
                <span className="text-white font-medium">12</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
