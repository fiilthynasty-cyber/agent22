import { Facebook, Instagram, Linkedin, Twitter, Plus, Heart, MessageCircle, Repeat, Eye, TrendingUp, Send } from 'lucide-react';
import { socialPosts, agents } from '../data/mockData';
import { cn } from '../utils/cn';
import { useState } from 'react';

export function SocialMedia() {
  const [activeTab, setActiveTab] = useState('posts');
  const socialAgents = agents.filter(a => a.team === 'social');

  const platforms = [
    { name: 'Facebook', icon: Facebook, followers: '12.5K', engagement: '+8.2%', color: 'blue' },
    { name: 'Instagram', icon: Instagram, followers: '28.3K', engagement: '+15.7%', color: 'pink' },
    { name: 'LinkedIn', icon: Linkedin, followers: '8.7K', engagement: '+12.4%', color: 'cyan' },
    { name: 'Twitter', icon: Twitter, followers: '15.2K', engagement: '+6.8%', color: 'sky' },
  ];

  const scheduledPosts = [
    { time: '2:00 PM', platform: 'instagram', content: 'Behind the scenes of our AI lab...', status: 'scheduled' },
    { time: '4:30 PM', platform: 'linkedin', content: 'New case study: How Company X increased...', status: 'scheduled' },
    { time: '6:00 PM', platform: 'facebook', content: 'Weekend special offer announcement...', status: 'draft' },
    { time: '8:00 PM', platform: 'twitter', content: 'Quick tip: 3 ways to improve your...', status: 'scheduled' },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Social Media Command</h1>
          <p className="text-slate-400">AI-powered social management by PULSE & VIRAL</p>
        </div>
        <button className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 text-white font-medium hover:from-pink-600 hover:to-rose-600 transition-all">
          <Plus className="w-5 h-5" />
          Create Post
        </button>
      </div>

      {/* Platform Stats */}
      <div className="grid grid-cols-4 gap-4">
        {platforms.map(platform => {
          const Icon = platform.icon;
          return (
            <div key={platform.name} className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6 hover:border-slate-600/50 transition-all">
              <div className="flex items-center justify-between mb-4">
                <div className={cn(
                  'w-12 h-12 rounded-xl flex items-center justify-center',
                  platform.color === 'blue' && 'bg-blue-500/20',
                  platform.color === 'pink' && 'bg-pink-500/20',
                  platform.color === 'cyan' && 'bg-cyan-500/20',
                  platform.color === 'sky' && 'bg-sky-500/20',
                )}>
                  <Icon className={cn(
                    'w-6 h-6',
                    platform.color === 'blue' && 'text-blue-400',
                    platform.color === 'pink' && 'text-pink-400',
                    platform.color === 'cyan' && 'text-cyan-400',
                    platform.color === 'sky' && 'text-sky-400',
                  )} />
                </div>
                <span className="text-xs font-medium text-emerald-400 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  {platform.engagement}
                </span>
              </div>
              <p className="text-2xl font-bold text-white mb-1">{platform.followers}</p>
              <p className="text-sm text-slate-400">{platform.name} Followers</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Content Calendar */}
        <div className="col-span-2 bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setActiveTab('posts')}
                className={cn(
                  'px-4 py-2 rounded-lg text-sm font-medium transition-all',
                  activeTab === 'posts' ? 'bg-pink-500/20 text-pink-400' : 'text-slate-400 hover:text-white'
                )}
              >
                Recent Posts
              </button>
              <button 
                onClick={() => setActiveTab('scheduled')}
                className={cn(
                  'px-4 py-2 rounded-lg text-sm font-medium transition-all',
                  activeTab === 'scheduled' ? 'bg-pink-500/20 text-pink-400' : 'text-slate-400 hover:text-white'
                )}
              >
                Scheduled
              </button>
              <button 
                onClick={() => setActiveTab('analytics')}
                className={cn(
                  'px-4 py-2 rounded-lg text-sm font-medium transition-all',
                  activeTab === 'analytics' ? 'bg-pink-500/20 text-pink-400' : 'text-slate-400 hover:text-white'
                )}
              >
                Analytics
              </button>
            </div>
          </div>

          {activeTab === 'posts' && (
            <div className="space-y-4">
              {socialPosts.map(post => (
                <div key={post.id} className="p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-all">
                  <div className="flex items-start gap-4">
                    <div className={cn(
                      'w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0',
                      post.platform === 'facebook' && 'bg-blue-500/20',
                      post.platform === 'instagram' && 'bg-pink-500/20',
                      post.platform === 'linkedin' && 'bg-cyan-500/20',
                      post.platform === 'twitter' && 'bg-sky-500/20',
                    )}>
                      {post.platform === 'facebook' && <Facebook className="w-5 h-5 text-blue-400" />}
                      {post.platform === 'instagram' && <Instagram className="w-5 h-5 text-pink-400" />}
                      {post.platform === 'linkedin' && <Linkedin className="w-5 h-5 text-cyan-400" />}
                      {post.platform === 'twitter' && <Twitter className="w-5 h-5 text-sky-400" />}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-slate-300 mb-3">{post.content}</p>
                      <div className="flex items-center gap-6">
                        <div className="flex items-center gap-2 text-sm text-slate-400">
                          <Heart className="w-4 h-4" />
                          <span>{post.engagement.likes}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-slate-400">
                          <MessageCircle className="w-4 h-4" />
                          <span>{post.engagement.comments}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-slate-400">
                          <Repeat className="w-4 h-4" />
                          <span>{post.engagement.shares}</span>
                        </div>
                      </div>
                    </div>
                    <span className={cn(
                      'px-3 py-1 rounded-full text-xs font-medium',
                      post.status === 'published' ? 'bg-emerald-500/20 text-emerald-400' :
                      post.status === 'scheduled' ? 'bg-amber-500/20 text-amber-400' :
                      'bg-slate-500/20 text-slate-400'
                    )}>
                      {post.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'scheduled' && (
            <div className="space-y-4">
              {scheduledPosts.map((post, idx) => (
                <div key={idx} className="flex items-center gap-4 p-4 rounded-xl bg-slate-800/50">
                  <div className="text-center">
                    <p className="text-lg font-bold text-white">{post.time}</p>
                    <p className="text-xs text-slate-400">Today</p>
                  </div>
                  <div className={cn(
                    'w-10 h-10 rounded-xl flex items-center justify-center',
                    post.platform === 'facebook' && 'bg-blue-500/20',
                    post.platform === 'instagram' && 'bg-pink-500/20',
                    post.platform === 'linkedin' && 'bg-cyan-500/20',
                    post.platform === 'twitter' && 'bg-sky-500/20',
                  )}>
                    {post.platform === 'facebook' && <Facebook className="w-5 h-5 text-blue-400" />}
                    {post.platform === 'instagram' && <Instagram className="w-5 h-5 text-pink-400" />}
                    {post.platform === 'linkedin' && <Linkedin className="w-5 h-5 text-cyan-400" />}
                    {post.platform === 'twitter' && <Twitter className="w-5 h-5 text-sky-400" />}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-slate-300">{post.content}</p>
                  </div>
                  <span className={cn(
                    'px-3 py-1 rounded-full text-xs font-medium',
                    post.status === 'scheduled' ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-500/20 text-slate-400'
                  )}>
                    {post.status}
                  </span>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'analytics' && (
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-slate-800/50">
                <div className="flex items-center gap-2 mb-2">
                  <Eye className="w-5 h-5 text-cyan-400" />
                  <span className="text-sm text-slate-400">Total Reach</span>
                </div>
                <p className="text-2xl font-bold text-white">1.2M</p>
                <p className="text-xs text-emerald-400">+23% vs last month</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-800/50">
                <div className="flex items-center gap-2 mb-2">
                  <Heart className="w-5 h-5 text-pink-400" />
                  <span className="text-sm text-slate-400">Engagements</span>
                </div>
                <p className="text-2xl font-bold text-white">48.7K</p>
                <p className="text-xs text-emerald-400">+18% vs last month</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-800/50">
                <div className="flex items-center gap-2 mb-2">
                  <MessageCircle className="w-5 h-5 text-purple-400" />
                  <span className="text-sm text-slate-400">Comments</span>
                </div>
                <p className="text-2xl font-bold text-white">5.2K</p>
                <p className="text-xs text-emerald-400">+12% vs last month</p>
              </div>
              <div className="p-4 rounded-xl bg-slate-800/50">
                <div className="flex items-center gap-2 mb-2">
                  <Repeat className="w-5 h-5 text-amber-400" />
                  <span className="text-sm text-slate-400">Shares</span>
                </div>
                <p className="text-2xl font-bold text-white">8.9K</p>
                <p className="text-xs text-emerald-400">+31% vs last month</p>
              </div>
            </div>
          )}
        </div>

        {/* Social Agents & Quick Post */}
        <div className="space-y-6">
          {/* Social Team */}
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Social Media Team</h3>
            <div className="space-y-3">
              {socialAgents.map(agent => (
                <div key={agent.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50">
                  <span className="text-2xl">{agent.avatar}</span>
                  <div className="flex-1">
                    <p className="font-medium text-white">{agent.name}</p>
                    <p className="text-xs text-slate-400">{agent.role}</p>
                  </div>
                  <div className={cn(
                    'w-2 h-2 rounded-full',
                    agent.status === 'active' ? 'bg-emerald-400' :
                    agent.status === 'busy' ? 'bg-amber-400 animate-pulse' : 'bg-slate-400'
                  )} />
                </div>
              ))}
            </div>
          </div>

          {/* Quick Post */}
          <div className="bg-gradient-to-br from-pink-500/10 to-purple-500/10 border border-pink-500/20 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Quick Post</h3>
            <textarea 
              className="w-full bg-slate-800/50 border border-slate-700 rounded-xl p-4 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-pink-500 h-24 resize-none mb-4"
              placeholder="What's on your mind? AI will optimize and schedule..."
            />
            <div className="flex items-center gap-2 mb-4">
              <button className="p-2 rounded-lg bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 transition-all">
                <Facebook className="w-4 h-4" />
              </button>
              <button className="p-2 rounded-lg bg-pink-500/20 text-pink-400 hover:bg-pink-500/30 transition-all">
                <Instagram className="w-4 h-4" />
              </button>
              <button className="p-2 rounded-lg bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30 transition-all">
                <Linkedin className="w-4 h-4" />
              </button>
              <button className="p-2 rounded-lg bg-sky-500/20 text-sky-400 hover:bg-sky-500/30 transition-all">
                <Twitter className="w-4 h-4" />
              </button>
            </div>
            <button className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gradient-to-r from-pink-500 to-purple-500 text-white font-medium hover:from-pink-600 hover:to-purple-600 transition-all">
              <Send className="w-4 h-4" />
              AI Optimize & Schedule
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
