import { ChevronRight, BarChart3 } from 'lucide-react';
import { teams, agents } from '../data/mockData';
import { cn } from '../utils/cn';
import { useState } from 'react';
import { TeamType } from '../types';

export function Teams() {
  const [selectedTeam, setSelectedTeam] = useState<TeamType | null>(null);
  
  const teamColors: Record<TeamType, string> = {
    secretary: 'from-cyan-500 to-blue-500',
    marketing: 'from-purple-500 to-pink-500',
    leads: 'from-emerald-500 to-cyan-500',
    social: 'from-pink-500 to-rose-500',
    engineering: 'from-amber-500 to-orange-500',
    oversight: 'from-indigo-500 to-purple-500',
  };

  const teamIcons: Record<TeamType, string> = {
    secretary: '👩‍💼',
    marketing: '📊',
    leads: '🎯',
    social: '📱',
    engineering: '⚙️',
    oversight: '👁️',
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">AI Team Command</h1>
          <p className="text-slate-400">Your complete AI workforce - {agents.length} agents across {teams.length} teams</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/30">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-sm font-medium text-emerald-400">
              {agents.filter(a => a.status === 'active' || a.status === 'busy').length} Active
            </span>
          </div>
        </div>
      </div>

      {/* Team Grid */}
      <div className="grid grid-cols-3 gap-6">
        {teams.map(team => (
          <div 
            key={team.id}
            onClick={() => setSelectedTeam(selectedTeam === team.id ? null : team.id)}
            className={cn(
              'bg-slate-900/50 backdrop-blur border rounded-2xl p-6 cursor-pointer transition-all hover:scale-[1.02]',
              selectedTeam === team.id ? 'border-cyan-500/50 shadow-lg shadow-cyan-500/10' : 'border-slate-700/50'
            )}
          >
            <div className="flex items-start justify-between mb-4">
              <div className={cn(
                'w-14 h-14 rounded-2xl flex items-center justify-center text-2xl bg-gradient-to-br',
                teamColors[team.id]
              )}>
                {teamIcons[team.id]}
              </div>
              <ChevronRight className={cn(
                'w-5 h-5 text-slate-500 transition-transform',
                selectedTeam === team.id && 'rotate-90 text-cyan-400'
              )} />
            </div>
            <h3 className="text-lg font-semibold text-white mb-1">{team.name}</h3>
            <p className="text-sm text-slate-400 mb-4">{team.description}</p>
            
            <div className="flex items-center gap-4 mb-4">
              <div className="flex -space-x-2">
                {team.agents.slice(0, 4).map(agent => (
                  <div 
                    key={agent.id} 
                    className="w-8 h-8 rounded-full bg-slate-700 border-2 border-slate-900 flex items-center justify-center text-sm"
                    title={agent.name}
                  >
                    {agent.avatar}
                  </div>
                ))}
                {team.agents.length > 4 && (
                  <div className="w-8 h-8 rounded-full bg-slate-700 border-2 border-slate-900 flex items-center justify-center text-xs text-slate-400">
                    +{team.agents.length - 4}
                  </div>
                )}
              </div>
              <span className="text-sm text-slate-400">{team.agents.length} agents</span>
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-slate-400">Performance</span>
                  <span className="text-xs font-medium text-white">{team.performance}%</span>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div 
                    className={cn('h-full rounded-full bg-gradient-to-r', teamColors[team.id])}
                    style={{ width: `${team.performance}%` }}
                  />
                </div>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400">Active Projects</span>
                <span className="text-white font-medium">{team.activeProjects}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Selected Team Details */}
      {selectedTeam && (
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className={cn(
                'w-12 h-12 rounded-xl flex items-center justify-center text-2xl bg-gradient-to-br',
                teamColors[selectedTeam]
              )}>
                {teamIcons[selectedTeam]}
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">
                  {teams.find(t => t.id === selectedTeam)?.name} Agents
                </h3>
                <p className="text-sm text-slate-400">Detailed agent status and performance</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-4">
            {agents.filter(a => a.team === selectedTeam).map(agent => (
              <div key={agent.id} className="bg-slate-800/50 rounded-xl p-4 hover:bg-slate-800 transition-all">
                <div className="flex items-center gap-3 mb-4">
                  <div className="relative">
                    <span className="text-3xl">{agent.avatar}</span>
                    <div className={cn(
                      'absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-slate-800',
                      agent.status === 'active' ? 'bg-emerald-400' :
                      agent.status === 'busy' ? 'bg-amber-400 animate-pulse' :
                      'bg-slate-400'
                    )} />
                  </div>
                  <div>
                    <p className="font-semibold text-white">{agent.name}</p>
                    <p className="text-xs text-slate-400">{agent.role}</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-400">Status</span>
                    <span className={cn(
                      'font-medium capitalize',
                      agent.status === 'active' ? 'text-emerald-400' :
                      agent.status === 'busy' ? 'text-amber-400' : 'text-slate-400'
                    )}>{agent.status}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-400">Tasks</span>
                    <span className="text-white font-medium">{agent.tasksCompleted.toLocaleString()}</span>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-slate-400">Efficiency</span>
                      <span className="text-white font-medium">{agent.efficiency}%</span>
                    </div>
                    <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                      <div 
                        className={cn('h-full rounded-full bg-gradient-to-r', teamColors[selectedTeam])}
                        style={{ width: `${agent.efficiency}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Team Performance Overview */}
      <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 to-purple-500/20 flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Team Performance Comparison</h3>
            <p className="text-sm text-slate-400">Real-time efficiency metrics across all teams</p>
          </div>
        </div>

        <div className="space-y-4">
          {teams.map(team => (
            <div key={team.id} className="flex items-center gap-4">
              <span className="text-2xl w-10">{teamIcons[team.id]}</span>
              <span className="w-32 text-sm text-slate-300">{team.name}</span>
              <div className="flex-1 h-8 bg-slate-800 rounded-lg overflow-hidden relative">
                <div 
                  className={cn('h-full rounded-lg bg-gradient-to-r transition-all duration-500', teamColors[team.id])}
                  style={{ width: `${team.performance}%` }}
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm font-bold text-white">
                  {team.performance}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
