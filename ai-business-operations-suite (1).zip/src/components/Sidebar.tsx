import { cn } from '../utils/cn';
import { 
  LayoutDashboard, 
  Phone, 
  Calendar, 
  Users, 
  Target, 
  Share2, 
  Star, 
  BarChart3, 
  Settings, 
  MessageSquare,
  Shield,
  Zap
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const menuItems = [
  { id: 'dashboard', label: 'Command Center', icon: LayoutDashboard },
  { id: 'calls', label: 'Call Center', icon: Phone },
  { id: 'appointments', label: 'Appointments', icon: Calendar },
  { id: 'leads', label: 'Lead Hunter', icon: Target },
  { id: 'teams', label: 'AI Teams', icon: Users },
  { id: 'social', label: 'Social Media', icon: Share2 },
  { id: 'reviews', label: 'Reviews', icon: Star },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'board', label: 'Board Room', icon: MessageSquare },
  { id: 'oversight', label: 'Oversight', icon: Shield },
];

export function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  return (
    <aside className="w-72 bg-gradient-to-b from-slate-900 via-slate-900 to-slate-800 border-r border-slate-700/50 flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-slate-700/50">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 via-blue-500 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/25">
            <Zap className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight">NexusAI</h1>
            <p className="text-xs text-slate-400 font-medium">Command Center</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1.5 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                'w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200',
                isActive 
                  ? 'bg-gradient-to-r from-cyan-500/20 via-blue-500/20 to-purple-500/20 text-white border border-cyan-500/30 shadow-lg shadow-cyan-500/10' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              )}
            >
              <Icon className={cn('w-5 h-5', isActive && 'text-cyan-400')} />
              {item.label}
              {isActive && (
                <div className="ml-auto w-2 h-2 rounded-full bg-cyan-400 shadow-lg shadow-cyan-400/50" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Settings */}
      <div className="p-4 border-t border-slate-700/50">
        <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-400 hover:text-white hover:bg-slate-800/50 transition-all">
          <Settings className="w-5 h-5" />
          Settings
        </button>
      </div>

      {/* System Status */}
      <div className="p-4 border-t border-slate-700/50">
        <div className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border border-emerald-500/20 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-lg shadow-emerald-400/50" />
            <span className="text-xs font-semibold text-emerald-400">SYSTEM ONLINE</span>
          </div>
          <p className="text-xs text-slate-400">All 22 AI agents operational</p>
          <p className="text-xs text-slate-500 mt-1">Uptime: 99.97%</p>
        </div>
      </div>
    </aside>
  );
}
