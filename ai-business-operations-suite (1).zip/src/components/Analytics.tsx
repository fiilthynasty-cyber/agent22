import { BarChart3, TrendingUp, Download, DollarSign, Users, Target, Phone } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, LineChart, Line } from 'recharts';
import { analyticsData } from '../data/mockData';
import { cn } from '../utils/cn';
import { useState } from 'react';

export function Analytics() {
  const [period, setPeriod] = useState('week');

  const revenueData = [
    { name: 'Week 1', revenue: 45000, target: 40000 },
    { name: 'Week 2', revenue: 52000, target: 45000 },
    { name: 'Week 3', revenue: 48000, target: 50000 },
    { name: 'Week 4', revenue: 61000, target: 55000 },
  ];

  const conversionData = [
    { name: 'Mon', rate: 12 },
    { name: 'Tue', rate: 15 },
    { name: 'Wed', rate: 11 },
    { name: 'Thu', rate: 18 },
    { name: 'Fri', rate: 14 },
    { name: 'Sat', rate: 8 },
    { name: 'Sun', rate: 6 },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Analytics & Reports</h1>
          <p className="text-slate-400">Comprehensive insights powered by ANALYST agent</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex bg-slate-800 rounded-xl p-1">
            {['day', 'week', 'month', 'year'].map(p => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={cn(
                  'px-4 py-2 rounded-lg text-sm font-medium transition-all capitalize',
                  period === p ? 'bg-cyan-500/20 text-cyan-400' : 'text-slate-400 hover:text-white'
                )}
              >
                {p}
              </button>
            ))}
          </div>
          <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 transition-all">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-emerald-400" />
            </div>
            <span className="text-xs font-medium text-emerald-400 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              +18.2%
            </span>
          </div>
          <p className="text-3xl font-bold text-white mb-1">$206,450</p>
          <p className="text-sm text-slate-400">Total Revenue</p>
        </div>
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/20 flex items-center justify-center">
              <Target className="w-6 h-6 text-cyan-400" />
            </div>
            <span className="text-xs font-medium text-emerald-400 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              +23.5%
            </span>
          </div>
          <p className="text-3xl font-bold text-white mb-1">1,847</p>
          <p className="text-sm text-slate-400">Leads Generated</p>
        </div>
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
              <Users className="w-6 h-6 text-purple-400" />
            </div>
            <span className="text-xs font-medium text-emerald-400 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              +12.8%
            </span>
          </div>
          <p className="text-3xl font-bold text-white mb-1">342</p>
          <p className="text-sm text-slate-400">New Clients</p>
        </div>
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 flex items-center justify-center">
              <Phone className="w-6 h-6 text-amber-400" />
            </div>
            <span className="text-xs font-medium text-emerald-400 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              +8.4%
            </span>
          </div>
          <p className="text-3xl font-bold text-white mb-1">2,156</p>
          <p className="text-sm text-slate-400">Calls Handled</p>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-6">Revenue vs Target</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="name" stroke="#64748b" fontSize={12} />
              <YAxis stroke="#64748b" fontSize={12} tickFormatter={(v) => `$${v/1000}k`} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1e293b', 
                  border: '1px solid #334155', 
                  borderRadius: '12px',
                  color: '#fff'
                }}
                formatter={(value) => [`$${Number(value).toLocaleString()}`, '']}
              />
              <Bar dataKey="target" fill="#334155" radius={[4, 4, 0, 0]} />
              <Bar dataKey="revenue" fill="#06b6d4" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Conversion Rate */}
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-6">Conversion Rate (%)</h3>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={conversionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="name" stroke="#64748b" fontSize={12} />
              <YAxis stroke="#64748b" fontSize={12} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1e293b', 
                  border: '1px solid #334155', 
                  borderRadius: '12px',
                  color: '#fff'
                }}
                formatter={(value) => [`${value}%`, 'Conversion']}
              />
              <Line type="monotone" dataKey="rate" stroke="#8b5cf6" strokeWidth={3} dot={{ fill: '#8b5cf6', strokeWidth: 2 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Team Performance & Daily Activity */}
      <div className="grid grid-cols-3 gap-6">
        {/* Team Performance */}
        <div className="col-span-2 bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-6">Daily Activity</h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={analyticsData.daily}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="name" stroke="#64748b" fontSize={12} />
              <YAxis stroke="#64748b" fontSize={12} yAxisId="left" />
              <YAxis stroke="#64748b" fontSize={12} yAxisId="right" orientation="right" tickFormatter={(v) => `$${v}`} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1e293b', 
                  border: '1px solid #334155', 
                  borderRadius: '12px',
                  color: '#fff'
                }} 
              />
              <Area yAxisId="right" type="monotone" dataKey="revenue" stroke="#10b981" fillOpacity={1} fill="url(#colorRevenue)" strokeWidth={2} />
              <Line yAxisId="left" type="monotone" dataKey="leads" stroke="#06b6d4" strokeWidth={2} dot={false} />
              <Line yAxisId="left" type="monotone" dataKey="calls" stroke="#8b5cf6" strokeWidth={2} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Reports */}
        <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Generated Reports</h3>
          <div className="space-y-3">
            {[
              { title: 'Daily Summary', date: 'Today', type: 'daily' },
              { title: 'Weekly Performance', date: 'This Week', type: 'weekly' },
              { title: 'Monthly Analytics', date: 'October 2024', type: 'monthly' },
              { title: 'Q3 Review', date: 'Q3 2024', type: 'quarterly' },
            ].map((report, idx) => (
              <div key={idx} className="flex items-center gap-3 p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-all cursor-pointer">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center">
                  <BarChart3 className="w-5 h-5 text-cyan-400" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-white">{report.title}</p>
                  <p className="text-xs text-slate-400">{report.date}</p>
                </div>
                <Download className="w-4 h-4 text-slate-500 hover:text-white transition-all" />
              </div>
            ))}
          </div>
          <button className="w-full mt-4 px-4 py-3 rounded-xl bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-500/30 text-cyan-400 font-medium hover:from-cyan-500/30 hover:to-purple-500/30 transition-all">
            Generate Custom Report
          </button>
        </div>
      </div>

      {/* Team Efficiency */}
      <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-white mb-6">Team Efficiency Breakdown</h3>
        <div className="grid grid-cols-6 gap-4">
          {analyticsData.teamPerformance.map(team => (
            <div key={team.team} className="text-center">
              <div className="relative w-24 h-24 mx-auto mb-3">
                <svg className="w-24 h-24 transform -rotate-90">
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke="#334155"
                    strokeWidth="8"
                    fill="none"
                  />
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke="url(#gradient)"
                    strokeWidth="8"
                    fill="none"
                    strokeDasharray={`${team.efficiency * 2.51} 251`}
                    strokeLinecap="round"
                  />
                  <defs>
                    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#06b6d4" />
                      <stop offset="100%" stopColor="#8b5cf6" />
                    </linearGradient>
                  </defs>
                </svg>
                <span className="absolute inset-0 flex items-center justify-center text-xl font-bold text-white">
                  {team.efficiency}%
                </span>
              </div>
              <p className="font-medium text-white">{team.team}</p>
              <p className="text-xs text-slate-400">{team.tasks} tasks</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
