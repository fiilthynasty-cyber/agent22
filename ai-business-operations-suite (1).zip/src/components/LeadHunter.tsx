import { Search, Mail, Phone, Globe, Linkedin, Facebook, Instagram, MoreVertical, Zap, ArrowRight } from 'lucide-react';
import { leads, agents } from '../data/mockData';
import { cn } from '../utils/cn';
import { useState } from 'react';

export function LeadHunter() {
  const [filter, setFilter] = useState('all');
  const leadAgents = agents.filter(a => a.team === 'leads');

  const filteredLeads = filter === 'all' 
    ? leads 
    : leads.filter(l => l.status === filter);

  const sources = [
    { name: 'Google', icon: Globe, count: 234, color: 'cyan' },
    { name: 'LinkedIn', icon: Linkedin, count: 187, color: 'blue' },
    { name: 'Facebook', icon: Facebook, count: 156, color: 'indigo' },
    { name: 'Instagram', icon: Instagram, count: 98, color: 'pink' },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Lead Hunter Command</h1>
          <p className="text-slate-400">AI agents scanning everywhere to pull in maximum leads</p>
        </div>
        <button className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 text-white font-medium hover:from-emerald-600 hover:to-cyan-600 transition-all">
          <Zap className="w-5 h-5" />
          Launch Hunt
        </button>
      </div>

      {/* Active Hunters */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-900/20 to-slate-900 border border-emerald-500/20 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse shadow-lg shadow-emerald-400/50" />
          <span className="text-sm font-semibold text-emerald-400">LEAD HUNTERS ACTIVE</span>
        </div>
        <div className="grid grid-cols-4 gap-4">
          {leadAgents.map(agent => (
            <div key={agent.id} className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-2xl">{agent.avatar}</span>
                <div>
                  <p className="font-semibold text-white">{agent.name}</p>
                  <p className="text-xs text-slate-400">{agent.role}</p>
                </div>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400">Leads found:</span>
                <span className="text-emerald-400 font-bold">{agent.tasksCompleted}</span>
              </div>
              <div className="mt-2 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-full animate-pulse"
                  style={{ width: `${agent.efficiency}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lead Sources */}
      <div className="grid grid-cols-4 gap-4">
        {sources.map(source => {
          const Icon = source.icon;
          return (
            <div key={source.name} className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6 hover:border-slate-600/50 transition-all">
              <div className={cn(
                'w-12 h-12 rounded-xl flex items-center justify-center mb-4',
                source.color === 'cyan' && 'bg-cyan-500/20',
                source.color === 'blue' && 'bg-blue-500/20',
                source.color === 'indigo' && 'bg-indigo-500/20',
                source.color === 'pink' && 'bg-pink-500/20',
              )}>
                <Icon className={cn(
                  'w-6 h-6',
                  source.color === 'cyan' && 'text-cyan-400',
                  source.color === 'blue' && 'text-blue-400',
                  source.color === 'indigo' && 'text-indigo-400',
                  source.color === 'pink' && 'text-pink-400',
                )} />
              </div>
              <p className="text-3xl font-bold text-white mb-1">{source.count}</p>
              <p className="text-sm text-slate-400">{source.name} Leads</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Lead Pipeline */}
        <div className="col-span-2 bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-white">Lead Pipeline</h3>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input 
                  type="text"
                  placeholder="Search leads..."
                  className="bg-slate-800 border border-slate-700 rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>
              <select 
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="all">All Status</option>
                <option value="new">New</option>
                <option value="contacted">Contacted</option>
                <option value="qualified">Qualified</option>
                <option value="booked">Booked</option>
              </select>
            </div>
          </div>

          {/* Lead Table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-3 px-4 text-xs font-semibold text-slate-400 uppercase">Lead</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-slate-400 uppercase">Source</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-slate-400 uppercase">Score</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-slate-400 uppercase">Status</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-slate-400 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredLeads.map(lead => (
                  <tr key={lead.id} className="border-b border-slate-800 hover:bg-slate-800/50 transition-all">
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center text-white font-bold text-sm">
                          {lead.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <p className="font-medium text-white">{lead.name}</p>
                          <p className="text-xs text-slate-400">{lead.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-sm text-slate-300">{lead.source}</span>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 bg-slate-700 rounded-full overflow-hidden">
                          <div 
                            className={cn(
                              'h-full rounded-full',
                              lead.score >= 90 ? 'bg-emerald-500' :
                              lead.score >= 75 ? 'bg-amber-500' : 'bg-slate-500'
                            )}
                            style={{ width: `${lead.score}%` }}
                          />
                        </div>
                        <span className={cn(
                          'text-sm font-bold',
                          lead.score >= 90 ? 'text-emerald-400' :
                          lead.score >= 75 ? 'text-amber-400' : 'text-slate-400'
                        )}>{lead.score}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className={cn(
                        'px-3 py-1 rounded-full text-xs font-medium',
                        lead.status === 'new' && 'bg-cyan-500/20 text-cyan-400',
                        lead.status === 'contacted' && 'bg-amber-500/20 text-amber-400',
                        lead.status === 'qualified' && 'bg-purple-500/20 text-purple-400',
                        lead.status === 'booked' && 'bg-emerald-500/20 text-emerald-400',
                      )}>
                        {lead.status}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <button className="p-2 rounded-lg bg-slate-700 hover:bg-slate-600 transition-all" title="Email">
                          <Mail className="w-4 h-4 text-slate-300" />
                        </button>
                        <button className="p-2 rounded-lg bg-slate-700 hover:bg-slate-600 transition-all" title="Call">
                          <Phone className="w-4 h-4 text-slate-300" />
                        </button>
                        <button className="p-2 rounded-lg bg-slate-700 hover:bg-slate-600 transition-all">
                          <MoreVertical className="w-4 h-4 text-slate-300" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Quick Actions & Stats */}
        <div className="space-y-6">
          {/* Outreach Queue */}
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">AI Outreach Queue</h3>
            <p className="text-sm text-slate-400 mb-4">LUNA is reaching out to hot leads</p>
            <div className="space-y-3">
              {leads.filter(l => l.score >= 80).slice(0, 3).map(lead => (
                <div key={lead.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center text-white text-xs font-bold">
                    {lead.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{lead.name}</p>
                    <p className="text-xs text-slate-400">Score: {lead.score}</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-amber-400" />
                </div>
              ))}
            </div>
            <button className="w-full mt-4 px-4 py-3 rounded-xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/30 text-amber-400 font-medium hover:from-amber-500/30 hover:to-orange-500/30 transition-all">
              View Full Queue
            </button>
          </div>

          {/* Conversion Stats */}
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Conversion Metrics</h3>
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-slate-400">Lead → Contacted</span>
                  <span className="text-sm font-medium text-white">87%</span>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full w-[87%] bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full" />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-slate-400">Contacted → Qualified</span>
                  <span className="text-sm font-medium text-white">64%</span>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full w-[64%] bg-gradient-to-r from-purple-500 to-pink-500 rounded-full" />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-slate-400">Qualified → Booked</span>
                  <span className="text-sm font-medium text-white">78%</span>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full w-[78%] bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-full" />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-slate-400">Booked → Closed</span>
                  <span className="text-sm font-medium text-white">92%</span>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full w-[92%] bg-gradient-to-r from-amber-500 to-orange-500 rounded-full" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
