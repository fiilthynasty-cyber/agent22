import { Star, ThumbsUp, MessageSquare, TrendingUp, Send, AlertCircle } from 'lucide-react';
import { reviews, agents } from '../data/mockData';
import { cn } from '../utils/cn';
import { useState } from 'react';

export function Reviews() {
  const [replyTexts, setReplyTexts] = useState<Record<string, string>>({});
  const reviewAgent = agents.find(a => a.name === 'REVIEW');

  const handleReplyChange = (reviewId: string, value: string) => {
    setReplyTexts(prev => ({ ...prev, [reviewId]: value }));
  };

  const stats = [
    { label: 'Average Rating', value: '4.9', icon: Star, color: 'amber' },
    { label: 'Total Reviews', value: '1,247', icon: MessageSquare, color: 'cyan' },
    { label: 'Response Rate', value: '98%', icon: ThumbsUp, color: 'emerald' },
    { label: 'Sentiment Score', value: '+94', icon: TrendingUp, color: 'purple' },
  ];

  const platforms = [
    { name: 'Google', reviews: 847, rating: 4.9, pending: 3 },
    { name: 'Yelp', reviews: 234, rating: 4.7, pending: 1 },
    { name: 'Facebook', reviews: 156, rating: 4.8, pending: 0 },
    { name: 'Trustpilot', reviews: 10, rating: 5.0, pending: 0 },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Review Management</h1>
          <p className="text-slate-400">AI-powered review monitoring and response by REVIEW agent</p>
        </div>
        <div className="flex items-center gap-3">
          {reviewAgent && (
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 border border-slate-700">
              <span className="text-xl">{reviewAgent.avatar}</span>
              <div>
                <p className="text-sm font-medium text-white">{reviewAgent.name}</p>
                <p className="text-xs text-slate-400">{reviewAgent.status}</p>
              </div>
              <div className={cn(
                'w-2 h-2 rounded-full ml-2',
                reviewAgent.status === 'active' ? 'bg-emerald-400' :
                reviewAgent.status === 'idle' ? 'bg-amber-400' : 'bg-slate-400'
              )} />
            </div>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
              <div className={cn(
                'w-12 h-12 rounded-xl flex items-center justify-center mb-4',
                stat.color === 'amber' && 'bg-amber-500/20',
                stat.color === 'cyan' && 'bg-cyan-500/20',
                stat.color === 'emerald' && 'bg-emerald-500/20',
                stat.color === 'purple' && 'bg-purple-500/20',
              )}>
                <Icon className={cn(
                  'w-6 h-6',
                  stat.color === 'amber' && 'text-amber-400',
                  stat.color === 'cyan' && 'text-cyan-400',
                  stat.color === 'emerald' && 'text-emerald-400',
                  stat.color === 'purple' && 'text-purple-400',
                )} />
              </div>
              <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
              <p className="text-sm text-slate-400">{stat.label}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Recent Reviews */}
        <div className="col-span-2 bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-white">Recent Reviews</h3>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-400 text-xs font-medium flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                4 Pending Response
              </span>
            </div>
          </div>

          <div className="space-y-4">
            {reviews.map(review => (
              <div key={review.id} className="p-5 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-all">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center text-white font-bold">
                      {review.author[0]}
                    </div>
                    <div>
                      <p className="font-medium text-white">{review.author}</p>
                      <p className="text-xs text-slate-400">{review.platform} • {review.createdAt.toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star 
                        key={i} 
                        className={cn(
                          'w-4 h-4',
                          i < review.rating ? 'text-amber-400 fill-amber-400' : 'text-slate-600'
                        )} 
                      />
                    ))}
                  </div>
                </div>
                <p className="text-slate-300 text-sm mb-4">{review.content}</p>
                
                {review.response ? (
                  <div className="bg-slate-700/50 rounded-lg p-4 border-l-4 border-cyan-500">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-cyan-400 text-xs font-medium">AI Response by REVIEW</span>
                    </div>
                    <p className="text-sm text-slate-300">{review.response}</p>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <input 
                      type="text"
                      placeholder="Type a response or let AI generate..."
                      value={replyTexts[review.id] || ''}
                      onChange={(e) => handleReplyChange(review.id, e.target.value)}
                      className="flex-1 bg-slate-700 border border-slate-600 rounded-lg px-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                    />
                    <button className="px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-500 text-white text-sm font-medium hover:from-cyan-600 hover:to-blue-600 transition-all flex items-center gap-2">
                      <Send className="w-4 h-4" />
                      Reply
                    </button>
                    <button className="px-4 py-2 rounded-lg bg-purple-500/20 text-purple-400 text-sm font-medium hover:bg-purple-500/30 transition-all">
                      AI Generate
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Platforms & Quick Stats */}
        <div className="space-y-6">
          {/* Platforms */}
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Review Platforms</h3>
            <div className="space-y-4">
              {platforms.map(platform => (
                <div key={platform.name} className="p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-all">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-white">{platform.name}</span>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                      <span className="text-sm font-bold text-white">{platform.rating}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-400">{platform.reviews} reviews</span>
                    {platform.pending > 0 && (
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-xs">
                        {platform.pending} pending
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Review Insights */}
          <div className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/20 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">AI Insights</h3>
            <div className="space-y-4">
              <div className="p-3 rounded-lg bg-slate-800/50">
                <p className="text-xs text-amber-400 font-medium mb-1">Most Mentioned</p>
                <p className="text-sm text-white">"Excellent customer service"</p>
              </div>
              <div className="p-3 rounded-lg bg-slate-800/50">
                <p className="text-xs text-emerald-400 font-medium mb-1">Positive Keywords</p>
                <div className="flex flex-wrap gap-1 mt-1">
                  {['Fast', 'Professional', 'Reliable', 'Amazing'].map(word => (
                    <span key={word} className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-xs">
                      {word}
                    </span>
                  ))}
                </div>
              </div>
              <div className="p-3 rounded-lg bg-slate-800/50">
                <p className="text-xs text-cyan-400 font-medium mb-1">Response Time</p>
                <p className="text-sm text-white">Avg: 2.3 hours</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
