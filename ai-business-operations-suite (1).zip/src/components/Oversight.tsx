import { Shield, Eye, AlertTriangle, CheckCircle2, TrendingUp, Activity, Bell, Settings, RefreshCw } from 'lucide-react';
import { teams, agents, tasks } from '../data/mockData';
import { cn } from '../utils/cn';
import { useState, useEffect } from 'react';

export function Oversight() {
  const [systemHealth, setSystemHealth] = useState(98.7);
  const oversightAgents = agents.filter(a => a.team === 'oversight');

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setSystemHealth(prev => {
        const change = (Math.random() - 0.5) * 0.2;
        return Math.min(100, Math.max(95, prev + change));
      });
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const alerts = [
    { id: 1, type: 'warning', message: 'Marketing campaign CTR below threshold', team: 'marketing', time: '5m ago' },
    { id: 2, type: 'info', message: 'Lead volume spike detected - scaling resources', team: 'leads', time: '12m ago' },
    { id: 3, type: 'success', message: 'Secretary team exceeded daily target', team: 'secretary', time: '1h ago' },
  ];

  const systemMetrics = [
    { name: 'API Response Time', value: '42ms', status: 'excellent' },
    { name: 'Agent Availability', value: '100%', status: 'excellent' },
    { name: 'Task Queue', value: '12 pending', status: 'good' },
    { name: 'Memory Usage', value: '67%', status: 'good' },
    { name: 'Error Rate', value: '0.02%', status: 'excellent' },
    { name: 'Uptime', value: '99.97%', status: 'excellent' },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Oversight Command</h1>
          <p className="text-slate-400">SENTINEL monitoring all teams and systems</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 transition-all">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
          <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 transition-all">
            <Settings className="w-4 h-4" />
            Settings
          </button>
        </div>
      </div>

      {/* System Status Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-900/30 to-slate-900 border border-emerald-500/30 rounded-2xl p-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/5 via-cyan-500/10 to-emerald-500/5" />
        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 border border-emerald-500/30 flex items-center justify-center">
              <Shield className="w-10 h-10 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse shadow-lg shadow-emerald-400/50" />
                <span className="text-sm font-semibold text-emerald-400">ALL SYSTEMS OPERATIONAL</span>
              </div>
              <h3 className="text-2xl font-bold text-white">System Health: {systemHealth.toFixed(1)}%</h3>
              <p className="text-slate-400">Last check: Just now</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-4xl font-bold text-white">{agents.filter(a => a.status !== 'idle').length}/{agents.length}</p>
            <p className="text-slate-400">Agents Active</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Team Monitoring */}
        <div className="col-span-2 bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-white mb-6">Team Performance Monitor</h3>
          <div className="space-y-4">
            {teams.map(team => {
              const activeAgents = team.agents.filter(a => a.status === 'active' || a.status === 'busy').length;
              const isPerforming = team.performance >= 95;
              return (
                <div key={team.id} className="p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-all">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        'w-10 h-10 rounded-xl flex items-center justify-center',
                        isPerforming ? 'bg-emerald-500/20' : 'bg-amber-500/20'
                      )}>
                        {isPerforming ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                        ) : (
                          <AlertTriangle className="w-5 h-5 text-amber-400" />
                        )}
                      </div>
                      <div>
                        <p className="font-semibold text-white">{team.name}</p>
                        <p className="text-xs text-slate-400">{activeAgents}/{team.agents.length} agents active</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm font-medium text-white">{team.performance}%</p>
                        <p className="text-xs text-slate-400">Efficiency</p>
                      </div>
                      <div className={cn(
                        'flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium',
                        team.performance >= 97 ? 'bg-emerald-500/20 text-emerald-400' :
                        team.performance >= 94 ? 'bg-cyan-500/20 text-cyan-400' :
                        'bg-amber-500/20 text-amber-400'
                      )}>
                        {team.performance >= 97 ? <TrendingUp className="w-3 h-3" /> : <Activity className="w-3 h-3" />}
                        {team.performance >= 97 ? 'Excellent' : team.performance >= 94 ? 'Good' : 'Monitor'}
                      </div>
                    </div>
                  </div>
                  <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className={cn(
                        'h-full rounded-full transition-all duration-500',
                        team.performance >= 97 ? 'bg-gradient-to-r from-emerald-500 to-cyan-500' :
                        team.performance >= 94 ? 'bg-gradient-to-r from-cyan-500 to-blue-500' :
                        'bg-gradient-to-r from-amber-500 to-orange-500'
                      )}
                      style={{ width: `${team.performance}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Alerts & Oversight Agents */}
        <div className="space-y-6">
          {/* Active Alerts */}
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Active Alerts</h3>
              <Bell className="w-5 h-5 text-slate-500" />
            </div>
            <div className="space-y-3">
              {alerts.map(alert => (
                <div key={alert.id} className={cn(
                  'p-3 rounded-xl',
                  alert.type === 'warning' && 'bg-amber-500/10 border border-amber-500/20',
                  alert.type === 'info' && 'bg-cyan-500/10 border border-cyan-500/20',
                  alert.type === 'success' && 'bg-emerald-500/10 border border-emerald-500/20',
                )}>
                  <div className="flex items-start gap-2">
                    {alert.type === 'warning' && <AlertTriangle className="w-4 h-4 text-amber-400 mt-0.5" />}
                    {alert.type === 'info' && <Eye className="w-4 h-4 text-cyan-400 mt-0.5" />}
                    {alert.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5" />}
                    <div className="flex-1">
                      <p className={cn(
                        'text-sm font-medium',
                        alert.type === 'warning' && 'text-amber-400',
                        alert.type === 'info' && 'text-cyan-400',
                        alert.type === 'success' && 'text-emerald-400',
                      )}>
                        {alert.team.charAt(0).toUpperCase() + alert.team.slice(1)} Team
                      </p>
                      <p className="text-xs text-slate-400">{alert.message}</p>
                      <p className="text-xs text-slate-500 mt-1">{alert.time}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Oversight Agents */}
          <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Oversight Team</h3>
            <div className="space-y-3">
              {oversightAgents.map(agent => (
                <div key={agent.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/50">
                  <span className="text-2xl">{agent.avatar}</span>
                  <div className="flex-1">
                    <p className="font-medium text-white">{agent.name}</p>
                    <p className="text-xs text-slate-400">{agent.role}</p>
                  </div>
                  <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-lg shadow-emerald-400/50" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* System Metrics */}
      <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-white mb-6">System Metrics</h3>
        <div className="grid grid-cols-6 gap-4">
          {systemMetrics.map(metric => (
            <div key={metric.name} className="p-4 rounded-xl bg-slate-800/50 text-center">
              <p className="text-2xl font-bold text-white mb-1">{metric.value}</p>
              <p className="text-xs text-slate-400 mb-2">{metric.name}</p>
              <span className={cn(
                'px-2 py-0.5 rounded-full text-xs font-medium',
                metric.status === 'excellent' ? 'bg-emerald-500/20 text-emerald-400' :
                metric.status === 'good' ? 'bg-cyan-500/20 text-cyan-400' :
                'bg-amber-500/20 text-amber-400'
              )}>
                {metric.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Active Tasks Overview */}
      <div className="bg-slate-900/50 backdrop-blur border border-slate-700/50 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-white mb-6">Active Task Overview</h3>
        <div className="grid grid-cols-5 gap-4">
          {tasks.map(task => (
            <div key={task.id} className={cn(
              'p-4 rounded-xl border',
              task.priority === 'urgent' ? 'bg-red-500/10 border-red-500/20' :
              task.priority === 'high' ? 'bg-amber-500/10 border-amber-500/20' :
              'bg-slate-800/50 border-slate-700/50'
            )}>
              <div className={cn(
                'text-xs font-medium mb-2',
                task.priority === 'urgent' ? 'text-red-400' :
                task.priority === 'high' ? 'text-amber-400' :
                'text-slate-400'
              )}>
                {task.priority.toUpperCase()}
              </div>
              <p className="text-sm font-medium text-white mb-1 line-clamp-2">{task.title}</p>
              <p className="text-xs text-slate-400">{task.assignedTo}</p>
              <div className={cn(
                'mt-2 px-2 py-0.5 rounded-full text-xs font-medium inline-block',
                task.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400' :
                task.status === 'in_progress' ? 'bg-cyan-500/20 text-cyan-400' :
                'bg-slate-500/20 text-slate-400'
              )}>
                {task.status.replace('_', ' ')}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
