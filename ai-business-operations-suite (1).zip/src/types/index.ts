export interface Agent {
  id: string;
  name: string;
  role: string;
  status: 'active' | 'idle' | 'busy';
  avatar: string;
  team: TeamType;
  tasksCompleted: number;
  efficiency: number;
}

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  source: string;
  status: 'new' | 'contacted' | 'qualified' | 'booked' | 'closed';
  score: number;
  createdAt: Date;
  assignedTo?: string;
}

export interface Appointment {
  id: string;
  clientName: string;
  clientEmail: string;
  date: Date;
  time: string;
  type: string;
  status: 'scheduled' | 'confirmed' | 'completed' | 'cancelled';
  notes?: string;
}

export interface Call {
  id: string;
  callerName: string;
  phone: string;
  duration: number;
  type: 'incoming' | 'outgoing';
  status: 'completed' | 'missed' | 'voicemail';
  summary?: string;
  timestamp: Date;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  assignedTo: string;
  team: TeamType;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'pending' | 'in_progress' | 'completed';
  dueDate: Date;
}

export interface Report {
  id: string;
  title: string;
  type: 'daily' | 'weekly' | 'monthly';
  generatedAt: Date;
  metrics: ReportMetrics;
}

export interface ReportMetrics {
  leadsGenerated: number;
  appointmentsBooked: number;
  callsHandled: number;
  conversionRate: number;
  revenue: number;
  socialEngagement: number;
}

export interface SocialPost {
  id: string;
  platform: 'facebook' | 'instagram' | 'twitter' | 'linkedin' | 'google';
  content: string;
  scheduledFor?: Date;
  status: 'draft' | 'scheduled' | 'published';
  engagement: {
    likes: number;
    comments: number;
    shares: number;
  };
}

export interface Review {
  id: string;
  platform: string;
  author: string;
  rating: number;
  content: string;
  response?: string;
  createdAt: Date;
}

export type TeamType = 'secretary' | 'marketing' | 'leads' | 'social' | 'engineering' | 'oversight';

export interface Team {
  id: TeamType;
  name: string;
  description: string;
  agents: Agent[];
  performance: number;
  activeProjects: number;
}

export interface BoardMeeting {
  id: string;
  title: string;
  scheduledFor: Date;
  attendees: string[];
  agenda: string[];
  status: 'scheduled' | 'in_progress' | 'completed';
  minutes?: string;
}
