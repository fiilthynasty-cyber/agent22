import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { CallCenter } from './components/CallCenter';
import { Appointments } from './components/Appointments';
import { LeadHunter } from './components/LeadHunter';
import { Teams } from './components/Teams';
import { SocialMedia } from './components/SocialMedia';
import { Reviews } from './components/Reviews';
import { Analytics } from './components/Analytics';
import { BoardRoom } from './components/BoardRoom';
import { Oversight } from './components/Oversight';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'calls':
        return <CallCenter />;
      case 'appointments':
        return <Appointments />;
      case 'leads':
        return <LeadHunter />;
      case 'teams':
        return <Teams />;
      case 'social':
        return <SocialMedia />;
      case 'reviews':
        return <Reviews />;
      case 'analytics':
        return <Analytics />;
      case 'board':
        return <BoardRoom />;
      case 'oversight':
        return <Oversight />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex font-['Inter',sans-serif]">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

export default App;
